import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertInvestmentPlanSchema, insertNewsArticleSchema, insertStockDataSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Investment Plans
  app.get("/api/investment-plans", async (req, res) => {
    try {
      const plans = await storage.getInvestmentPlans();
      res.json(plans);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch investment plans" });
    }
  });

  app.get("/api/investment-plans/:id", async (req, res) => {
    try {
      const plan = await storage.getInvestmentPlan(req.params.id);
      if (!plan) {
        return res.status(404).json({ message: "Investment plan not found" });
      }
      res.json(plan);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch investment plan" });
    }
  });

  // Portfolio endpoints (mock data for demo)
  app.get("/api/portfolio/stats", async (req, res) => {
    try {
      // Mock portfolio statistics
      const stats = {
        totalValue: "12847",
        dailyPnL: "+284",
        dailyPnLPercent: "+2.27",
        totalInvestors: "15742",
        avgReturn: "+24.7",
        totalInvested: "$2.8M",
        roi: "+18.3",
        riskScore: "7.2"
      };
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch portfolio stats" });
    }
  });

  app.get("/api/portfolio/performance", async (req, res) => {
    try {
      // Mock performance data for charts
      const performance = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        data: [10000, 10500, 11200, 10800, 12100, 12847]
      };
      res.json(performance);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch portfolio performance" });
    }
  });

  app.get("/api/portfolio/holdings", async (req, res) => {
    try {
      // Mock holdings breakdown
      const holdings = {
        tsla: { value: "$8,500", percentage: "66.2%" },
        etf: { value: "$3,200", percentage: "24.9%" },
        cash: { value: "$1,147", percentage: "8.9%" }
      };
      res.json(holdings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch holdings" });
    }
  });

  // Stock Data
  app.get("/api/stock", async (req, res) => {
    try {
      const stockData = await storage.getStockData();
      if (!stockData) {
        return res.status(404).json({ message: "Stock data not found" });
      }
      res.json(stockData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stock data" });
    }
  });

  app.get("/api/stock/chart", async (req, res) => {
    try {
      // Mock intraday stock data
      const chartData = {
        labels: ['9:30', '10:00', '10:30', '11:00', '11:30', '12:00', '12:30', '1:00'],
        data: [236.10, 238.50, 241.20, 245.80, 248.90, 246.30, 248.50, 250.10]
      };
      res.json(chartData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stock chart data" });
    }
  });

  // News Articles
  app.get("/api/news", async (req, res) => {
    try {
      const articles = await storage.getNewsArticles();
      res.json(articles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch news articles" });
    }
  });

  // Technical Analysis
  app.get("/api/analysis/technical", async (req, res) => {
    try {
      // Mock technical indicators
      const technical = {
        rsi: "65.4 (Bullish)",
        macd: "2.3 (Buy Signal)",
        bollinger: "Neutral"
      };
      res.json(technical);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch technical analysis" });
    }
  });

  app.get("/api/analysis/levels", async (req, res) => {
    try {
      // Mock support/resistance levels
      const levels = {
        resistance: "$265.00",
        support: "$235.00",
        target: "$275.00"
      };
      res.json(levels);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch price levels" });
    }
  });

  // Market Sentiment
  app.get("/api/sentiment", async (req, res) => {
    try {
      const sentiment = {
        bullish: 72,
        bearish: 28,
        analysts: [
          { firm: "Morgan Stanley", rating: "BUY", target: "$300", color: "green" },
          { firm: "Goldman Sachs", rating: "HOLD", target: "$275", color: "blue" },
          { firm: "JP Morgan", rating: "NEUTRAL", target: "$250", color: "yellow" }
        ]
      };
      res.json(sentiment);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch market sentiment" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
