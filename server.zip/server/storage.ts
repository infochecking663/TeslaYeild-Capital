import {
  type User,
  type InsertUser,
  type InvestmentPlan,
  type InsertInvestmentPlan,
  type Portfolio,
  type InsertPortfolio,
  type NewsArticle,
  type InsertNewsArticle,
  type StockData,
  type InsertStockData,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getInvestmentPlans(): Promise<InvestmentPlan[]>;
  getInvestmentPlan(id: string): Promise<InvestmentPlan | undefined>;
  
  getPortfolios(userId: string): Promise<Portfolio[]>;
  createPortfolio(portfolio: InsertPortfolio): Promise<Portfolio>;
  
  getNewsArticles(): Promise<NewsArticle[]>;
  createNewsArticle(article: InsertNewsArticle): Promise<NewsArticle>;
  
  getStockData(): Promise<StockData | undefined>;
  updateStockData(data: InsertStockData): Promise<StockData>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private investmentPlans: Map<string, InvestmentPlan>;
  private portfolios: Map<string, Portfolio>;
  private newsArticles: Map<string, NewsArticle>;
  private stockData: StockData | undefined;

  constructor() {
    this.users = new Map();
    this.investmentPlans = new Map();
    this.portfolios = new Map();
    this.newsArticles = new Map();
    
    // Initialize with mock data
    this.initializeMockData();
  }

  private initializeMockData() {
    // Investment Plans
    const plans: InvestmentPlan[] = [
      {
        id: "plan-1",
        name: "Starter Plan",
        minimumInvestment: "500",
        features: [
          "Real-time portfolio tracking",
          "Basic Tesla news feed",
          "Monthly performance reports",
          "Email support"
        ],
        isPopular: "false"
      },
      {
        id: "plan-2",
        name: "Professional Plan",
        minimumInvestment: "2500",
        features: [
          "Advanced portfolio analytics",
          "Premium Tesla insights",
          "Weekly strategy calls",
          "Risk management tools",
          "Priority support"
        ],
        isPopular: "true"
      },
      {
        id: "plan-3",
        name: "Elite Plan",
        minimumInvestment: "10000",
        features: [
          "Institutional-grade analytics",
          "Exclusive market intelligence",
          "Personal investment advisor",
          "Custom portfolio strategies",
          "24/7 concierge support"
        ],
        isPopular: "false"
      }
    ];
    
    plans.forEach(plan => this.investmentPlans.set(plan.id, plan));

    // Stock Data
    this.stockData = {
      id: "stock-1",
      symbol: "TSLA",
      currentPrice: "248.50",
      change: "12.40",
      changePercent: "5.2",
      volume: "24.7M",
      marketCap: "$784B",
      updatedAt: new Date()
    };

    // News Articles
    const articles: NewsArticle[] = [
      {
        id: "news-1",
        title: "Tesla Reports Record Q4 Production Numbers, Beats Analyst Expectations",
        content: "Tesla announced record-breaking production figures for Q4, with over 484,000 vehicles delivered globally. The company's Gigafactories in Texas and Berlin continue to ramp up production capacity...",
        excerpt: "Tesla announced record-breaking production figures for Q4, with over 484,000 vehicles delivered globally.",
        imageUrl: "https://images.unsplash.com/photo-1581092162384-8987c1d64718?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        stockImpact: "+8.2%",
        publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000) // 2 hours ago
      },
      {
        id: "news-2",
        title: "Tesla Expands Supercharger Network to 45,000 Stations Globally",
        content: "Company announces major infrastructure investment to support growing EV adoption rates across North America and Europe.",
        excerpt: "Company announces major infrastructure investment to support growing EV adoption rates.",
        imageUrl: "https://images.unsplash.com/photo-1593941707882-a5bac6861d75?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        stockImpact: "+2.1%",
        publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000) // 4 hours ago
      },
      {
        id: "news-3",
        title: "Full Self-Driving Beta Expands to 160,000 Tesla Owners",
        content: "Tesla's FSD beta program reaches new milestone as autonomous driving capabilities show significant improvement.",
        excerpt: "Tesla's FSD beta program reaches new milestone as autonomous driving capabilities show significant improvement.",
        imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        stockImpact: "+5.7%",
        publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000) // 6 hours ago
      }
    ];
    
    articles.forEach(article => this.newsArticles.set(article.id, article));
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getInvestmentPlans(): Promise<InvestmentPlan[]> {
    return Array.from(this.investmentPlans.values());
  }

  async getInvestmentPlan(id: string): Promise<InvestmentPlan | undefined> {
    return this.investmentPlans.get(id);
  }

  async getPortfolios(userId: string): Promise<Portfolio[]> {
    return Array.from(this.portfolios.values()).filter(
      (portfolio) => portfolio.userId === userId
    );
  }

  async createPortfolio(insertPortfolio: InsertPortfolio): Promise<Portfolio> {
    const id = randomUUID();
    const portfolio: Portfolio = { 
      ...insertPortfolio, 
      id,
      createdAt: new Date()
    };
    this.portfolios.set(id, portfolio);
    return portfolio;
  }

  async getNewsArticles(): Promise<NewsArticle[]> {
    return Array.from(this.newsArticles.values()).sort(
      (a, b) => (b.publishedAt?.getTime() || 0) - (a.publishedAt?.getTime() || 0)
    );
  }

  async createNewsArticle(insertArticle: InsertNewsArticle): Promise<NewsArticle> {
    const id = randomUUID();
    const article: NewsArticle = { 
      ...insertArticle, 
      id,
      publishedAt: new Date()
    };
    this.newsArticles.set(id, article);
    return article;
  }

  async getStockData(): Promise<StockData | undefined> {
    return this.stockData;
  }

  async updateStockData(insertData: InsertStockData): Promise<StockData> {
    const id = this.stockData?.id || randomUUID();
    this.stockData = { 
      ...insertData, 
      id,
      updatedAt: new Date()
    };
    return this.stockData;
  }
}

export const storage = new MemStorage();
