import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import LoadingSpinner from "@/components/ui/loading-spinner";

export default function HeroSection() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/portfolio/stats'],
  });

  const { data: stockData } = useQuery({
    queryKey: ['/api/stock'],
  });

  const scrollToPlans = () => {
    const element = document.getElementById('plans');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToDashboard = () => {
    const element = document.getElementById('dashboard');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="gradient-overlay text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-in-up">
            <h1 className="text-5xl font-bold mb-6 leading-tight">
              Invest in Tesla's <span className="tesla-red">Electric Future</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Professional investment solutions starting at $500. Track real-time ROI, 
              access curated Tesla insights, and grow with the future of sustainable transportation.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={scrollToPlans}
                className="bg-tesla-red text-white px-8 py-4 text-lg font-semibold hover:bg-red-700 transition-colors"
              >
                Start Investing Today
              </Button>
              <Button 
                onClick={scrollToDashboard}
                variant="outline" 
                className="border-gray-400 text-white px-8 py-4 text-lg font-semibold hover:bg-white hover:text-[var(--tesla-dark)] transition-colors"
              >
                View Performance
              </Button>
            </div>
            
            {isLoading ? (
              <div className="flex items-center justify-center mt-8">
                <LoadingSpinner />
              </div>
            ) : stats && (
              <div className="flex flex-wrap items-center mt-8 space-x-8 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold tesla-red">{stats.totalInvestors}</div>
                  <div className="text-sm text-gray-400">Active Investors</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-400">{stats.avgReturn}%</div>
                  <div className="text-sm text-gray-400">Avg. Annual Return</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400">{stats.totalInvested}</div>
                  <div className="text-sm text-gray-400">Total Invested</div>
                </div>
              </div>
            )}
          </div>

          <div className="relative animate-fade-in-up">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
              <img 
                src="https://images.unsplash.com/photo-1560958089-b8a1929cea89?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Tesla Model S in modern showroom" 
                className="rounded-xl w-full h-64 object-cover mb-6" 
              />
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-green-500/20 rounded-lg p-4">
                  <div className="text-green-400 text-2xl font-bold">
                    ${stockData?.currentPrice || '248.50'}
                  </div>
                  <div className="text-green-400 text-sm">
                    +{stockData?.changePercent || '5.2'}%
                  </div>
                </div>
                <div className="bg-blue-500/20 rounded-lg p-4">
                  <div className="text-blue-400 text-2xl font-bold">
                    {stats?.roi || '+18.3'}%
                  </div>
                  <div className="text-blue-400 text-sm">Your ROI</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
