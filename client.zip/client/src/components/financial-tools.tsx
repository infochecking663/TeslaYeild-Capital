import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import LoadingSpinner from "@/components/ui/loading-spinner";

interface CalculatorState {
  initialInvestment: string;
  period: string;
  expectedReturn: string;
  projectedValue: string;
  totalReturn: string;
}

interface RiskAssessment {
  experience: string;
  tolerance: string;
  timeline: string;
  profile: string;
  recommendation: string;
  riskLevel: number;
}

export default function FinancialTools() {
  const [calculator, setCalculator] = useState<CalculatorState>({
    initialInvestment: '5000',
    period: '1 year',
    expectedReturn: '15',
    projectedValue: '5750',
    totalReturn: '750'
  });

  const [riskAssessment, setRiskAssessment] = useState<RiskAssessment>({
    experience: '',
    tolerance: '',
    timeline: '',
    profile: 'Moderate Risk Profile',
    recommendation: 'Based on your inputs, you have a moderate risk tolerance. Consider diversifying with 70% TSLA stock and 30% ETFs.',
    riskLevel: 60
  });

  const { data: technical } = useQuery({
    queryKey: ['/api/analysis/technical'],
  });

  const { data: levels } = useQuery({
    queryKey: ['/api/analysis/levels'],
  });

  const calculateROI = () => {
    const initial = parseFloat(calculator.initialInvestment) || 0;
    const returnRate = parseFloat(calculator.expectedReturn) || 0;
    const years = calculator.period === '6 months' ? 0.5 : 
                  calculator.period === '1 year' ? 1 : 
                  calculator.period === '2 years' ? 2 : 5;
    
    const projected = initial * Math.pow(1 + returnRate / 100, years);
    const totalReturn = projected - initial;
    
    setCalculator(prev => ({
      ...prev,
      projectedValue: projected.toLocaleString(),
      totalReturn: totalReturn.toLocaleString()
    }));
  };

  const assessRisk = () => {
    let riskScore = 0;
    
    // Experience scoring
    if (riskAssessment.experience === 'beginner') riskScore += 20;
    else if (riskAssessment.experience === 'intermediate') riskScore += 50;
    else if (riskAssessment.experience === 'expert') riskScore += 80;
    
    // Tolerance scoring
    if (riskAssessment.tolerance === 'conservative') riskScore += 10;
    else if (riskAssessment.tolerance === 'moderate') riskScore += 50;
    else if (riskAssessment.tolerance === 'aggressive') riskScore += 90;
    
    // Timeline scoring
    if (riskAssessment.timeline === 'short') riskScore += 20;
    else if (riskAssessment.timeline === 'medium') riskScore += 50;
    else if (riskAssessment.timeline === 'long') riskScore += 80;
    
    const finalScore = Math.round(riskScore / 3);
    
    let profile = 'Conservative Risk Profile';
    let recommendation = 'Consider low-risk investments with 30% TSLA stock and 70% bonds/cash.';
    
    if (finalScore >= 70) {
      profile = 'Aggressive Risk Profile';
      recommendation = 'You can handle high-risk investments. Consider 90% TSLA stock and 10% cash reserve.';
    } else if (finalScore >= 40) {
      profile = 'Moderate Risk Profile';
      recommendation = 'Balanced approach recommended. Consider 70% TSLA stock and 30% ETFs/bonds.';
    }
    
    setRiskAssessment(prev => ({
      ...prev,
      profile,
      recommendation,
      riskLevel: finalScore
    }));
  };

  return (
    <section id="tools" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold tesla-dark mb-4">Financial Tools & Calculators</h2>
          <p className="text-xl text-gray-600">
            Professional investment tools to optimize your Tesla portfolio strategy
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* ROI Calculator */}
          <Card className="shadow-lg border border-gray-200">
            <CardContent className="p-8">
              <h3 className="text-2xl font-semibold tesla-dark mb-6">ROI Calculator</h3>
              <div className="space-y-6">
                <div>
                  <Label htmlFor="initial-investment" className="block text-sm font-medium text-gray-700 mb-2">
                    Initial Investment
                  </Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                    <Input 
                      id="initial-investment"
                      type="number" 
                      placeholder="5000" 
                      className="pl-8"
                      value={calculator.initialInvestment}
                      onChange={(e) => setCalculator(prev => ({ ...prev, initialInvestment: e.target.value }))}
                    />
                  </div>
                </div>
                
                <div>
                  <Label className="block text-sm font-medium text-gray-700 mb-2">Investment Period</Label>
                  <Select 
                    value={calculator.period} 
                    onValueChange={(value) => setCalculator(prev => ({ ...prev, period: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="6 months">6 months</SelectItem>
                      <SelectItem value="1 year">1 year</SelectItem>
                      <SelectItem value="2 years">2 years</SelectItem>
                      <SelectItem value="5 years">5 years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="expected-return" className="block text-sm font-medium text-gray-700 mb-2">
                    Expected Annual Return
                  </Label>
                  <div className="relative">
                    <Input 
                      id="expected-return"
                      type="number" 
                      placeholder="15" 
                      className="pr-8"
                      value={calculator.expectedReturn}
                      onChange={(e) => setCalculator(prev => ({ ...prev, expectedReturn: e.target.value }))}
                    />
                    <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500">%</span>
                  </div>
                </div>
                
                <Button 
                  onClick={calculateROI}
                  className="w-full bg-tesla-red text-white font-semibold hover:bg-red-700"
                >
                  Calculate Returns
                </Button>
                
                {/* Results Display */}
                <div className="bg-gray-50 rounded-lg p-6 mt-6">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-green-600">${calculator.projectedValue}</div>
                      <div className="text-sm text-gray-600">Projected Value</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold tesla-red">${calculator.totalReturn}</div>
                      <div className="text-sm text-gray-600">Total Return</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Risk Assessment Tool */}
          <Card className="shadow-lg border border-gray-200">
            <CardContent className="p-8">
              <h3 className="text-2xl font-semibold tesla-dark mb-6">Risk Assessment</h3>
              <div className="space-y-6">
                <div>
                  <Label className="block text-sm font-medium text-gray-700 mb-3">Investment Experience</Label>
                  <RadioGroup 
                    value={riskAssessment.experience} 
                    onValueChange={(value) => setRiskAssessment(prev => ({ ...prev, experience: value }))}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="beginner" id="beginner" />
                      <Label htmlFor="beginner">Beginner (0-2 years)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="intermediate" id="intermediate" />
                      <Label htmlFor="intermediate">Intermediate (3-7 years)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="expert" id="expert" />
                      <Label htmlFor="expert">Expert (8+ years)</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div>
                  <Label className="block text-sm font-medium text-gray-700 mb-3">Risk Tolerance</Label>
                  <RadioGroup 
                    value={riskAssessment.tolerance} 
                    onValueChange={(value) => setRiskAssessment(prev => ({ ...prev, tolerance: value }))}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="conservative" id="conservative" />
                      <Label htmlFor="conservative">Conservative</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="moderate" id="moderate" />
                      <Label htmlFor="moderate">Moderate</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="aggressive" id="aggressive" />
                      <Label htmlFor="aggressive">Aggressive</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div>
                  <Label className="block text-sm font-medium text-gray-700 mb-2">Investment Timeline</Label>
                  <Select 
                    value={riskAssessment.timeline} 
                    onValueChange={(value) => setRiskAssessment(prev => ({ ...prev, timeline: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select timeline" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="short">Short-term (1-3 years)</SelectItem>
                      <SelectItem value="medium">Medium-term (4-7 years)</SelectItem>
                      <SelectItem value="long">Long-term (8+ years)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Button 
                  onClick={assessRisk}
                  className="w-full bg-tesla-red text-white font-semibold hover:bg-red-700"
                >
                  Assess Risk Profile
                </Button>
                
                {/* Risk Profile Result */}
                <div className="bg-gray-50 rounded-lg p-6">
                  <div className="text-center">
                    <div className="text-xl font-bold tesla-dark mb-2">{riskAssessment.profile}</div>
                    <div className="w-full bg-gray-200 rounded-full h-3 mb-3">
                      <div 
                        className="bg-yellow-500 h-3 rounded-full transition-all duration-500" 
                        style={{ width: `${riskAssessment.riskLevel}%` }}
                      ></div>
                    </div>
                    <p className="text-sm text-gray-600">{riskAssessment.recommendation}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Market Analysis Tools */}
        <div className="mt-12">
          <Card className="shadow-lg border border-gray-200">
            <CardContent className="p-8">
              <h3 className="text-2xl font-semibold tesla-dark mb-8">Market Analysis Dashboard</h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-lg font-semibold tesla-dark mb-4">Technical Indicators</h4>
                  <img 
                    src="https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300" 
                    alt="Investment dashboard displaying technical analysis charts and indicators" 
                    className="w-full h-48 object-cover rounded-lg mb-4" 
                  />
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <span className="font-medium">RSI (14)</span>
                      <span className="text-green-600 font-semibold">
                        {technical?.rsi || '65.4 (Bullish)'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                      <span className="font-medium">MACD</span>
                      <span className="text-blue-600 font-semibold">
                        {technical?.macd || '2.3 (Buy Signal)'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                      <span className="font-medium">Bollinger Bands</span>
                      <span className="text-yellow-600 font-semibold">
                        {technical?.bollinger || 'Neutral'}
                      </span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="text-lg font-semibold tesla-dark mb-4">Support & Resistance</h4>
                  <img 
                    src="https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300" 
                    alt="Financial market chart showing support and resistance levels with candlestick patterns" 
                    className="w-full h-48 object-cover rounded-lg mb-4" 
                  />
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                      <span className="font-medium">Resistance Level</span>
                      <span className="text-red-600 font-semibold">
                        {levels?.resistance || '$265.00'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <span className="font-medium">Support Level</span>
                      <span className="text-green-600 font-semibold">
                        {levels?.support || '$235.00'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">Price Target</span>
                      <span className="tesla-dark font-semibold">
                        {levels?.target || '$275.00'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
