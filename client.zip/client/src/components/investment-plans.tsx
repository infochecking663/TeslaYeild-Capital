import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import LoadingSpinner from "@/components/ui/loading-spinner";
import type { InvestmentPlan } from "@shared/schema";

export default function InvestmentPlans() {
  const { data: plans, isLoading, error } = useQuery<InvestmentPlan[]>({
    queryKey: ['/api/investment-plans'],
  });

  if (isLoading) {
    return (
      <section id="plans" className="py-20 bg-light-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center">
            <LoadingSpinner />
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section id="plans" className="py-20 bg-light-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-red-500">
            Failed to load investment plans. Please try again later.
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="plans" className="py-20 bg-light-gray">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold tesla-dark mb-4">Choose Your Investment Plan</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Professional investment solutions designed to maximize your Tesla portfolio growth 
            with comprehensive risk management.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans?.map((plan, index) => (
            <div 
              key={plan.id}
              className={`bg-white rounded-2xl shadow-lg p-8 border-2 transition-all duration-300 transform hover:-translate-y-2 ${
                plan.isPopular === "true" 
                  ? "border-[var(--tesla-red)] scale-105 relative" 
                  : "border-transparent hover:border-[var(--tesla-red)]"
              }`}
            >
              {plan.isPopular === "true" && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-tesla-red text-white px-6 py-2 rounded-full text-sm font-semibold">
                  Most Popular
                </div>
              )}
              
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold tesla-dark mb-2">{plan.name}</h3>
                <div className="text-4xl font-bold tesla-red mb-2">
                  ${parseFloat(plan.minimumInvestment).toLocaleString()}
                </div>
                <div className="text-gray-600">Minimum Investment</div>
              </div>
              
              <ul className="space-y-4 mb-8">
                {(plan.features as string[]).map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-gray-700">
                    <Check className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
              
              <Button 
                className={`w-full py-3 font-semibold transition-colors ${
                  plan.isPopular === "true"
                    ? "bg-tesla-red text-white hover:bg-red-700"
                    : "bg-gray-200 text-[var(--tesla-dark)] hover:bg-tesla-red hover:text-white"
                }`}
              >
                Choose Plan
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
