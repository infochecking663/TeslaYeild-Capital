import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import LoadingSpinner from "@/components/ui/loading-spinner";
import type { NewsArticle } from "@shared/schema";

export default function TeslaNews() {
  const { data: articles, isLoading, error } = useQuery<NewsArticle[]>({
    queryKey: ['/api/news'],
  });

  const { data: stockData } = useQuery({
    queryKey: ['/api/stock'],
  });

  const { data: sentiment } = useQuery({
    queryKey: ['/api/sentiment'],
  });

  const formatTimeAgo = (date: Date | string | undefined) => {
    if (!date) return 'Just now';
    const now = new Date();
    const articleDate = new Date(date);
    const diffInHours = Math.floor((now.getTime() - articleDate.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours === 1) return '1 hour ago';
    return `${diffInHours} hours ago`;
  };

  if (isLoading) {
    return (
      <section id="news" className="py-20 bg-light-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center">
            <LoadingSpinner />
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section id="news" className="py-20 bg-light-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-red-500">
            Failed to load Tesla news. Please try again later.
          </div>
        </div>
      </section>
    );
  }

  const featuredArticle = articles?.[0];
  const otherArticles = articles?.slice(1) || [];

  return (
    <section id="news" className="py-20 bg-light-gray">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold tesla-dark mb-4">Tesla Market Intelligence</h2>
          <p className="text-xl text-gray-600">
            Stay informed with curated Tesla news, analysis, and market insights
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Featured News */}
          <div className="lg:col-span-2">
            {featuredArticle && (
              <Card className="mb-8 shadow-lg overflow-hidden">
                <img 
                  src={featuredArticle.imageUrl || 'https://images.unsplash.com/photo-1581092162384-8987c1d64718?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400'} 
                  alt={featuredArticle.title} 
                  className="w-full h-64 object-cover" 
                />
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <span className="bg-tesla-red text-white px-3 py-1 rounded-full text-sm font-medium">
                      Breaking
                    </span>
                    <span className="text-gray-500 text-sm ml-4">
                      {formatTimeAgo(featuredArticle.publishedAt)}
                    </span>
                  </div>
                  <h3 className="text-2xl font-bold tesla-dark mb-3">
                    {featuredArticle.title}
                  </h3>
                  <p className="text-gray-600 mb-4">
                    {featuredArticle.excerpt}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="text-green-500 font-semibold">
                        Stock Impact: {featuredArticle.stockImpact || '+8.2%'}
                      </div>
                      <div className="text-sm text-gray-500">
                        Market Cap: {stockData?.marketCap || '$784B'}
                      </div>
                    </div>
                    <Button variant="ghost" className="tesla-red font-medium hover:underline">
                      Read Full Article
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* News List */}
            <div className="space-y-6">
              {otherArticles.map((article) => (
                <Card key={article.id} className="shadow-lg">
                  <CardContent className="p-6 flex items-center space-x-6">
                    <img 
                      src={article.imageUrl || 'https://images.unsplash.com/photo-1593941707882-a5bac6861d75?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=150'} 
                      alt={article.title} 
                      className="w-24 h-20 object-cover rounded-lg flex-shrink-0" 
                    />
                    <div className="flex-1">
                      <h4 className="text-lg font-semibold tesla-dark mb-2">
                        {article.title}
                      </h4>
                      <p className="text-gray-600 text-sm mb-2">
                        {article.excerpt}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-500 text-xs">
                          {formatTimeAgo(article.publishedAt)}
                        </span>
                        <span className="text-blue-500 text-sm font-medium">
                          {article.stockImpact || '+2.1%'} Impact
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Market Data Sidebar */}
          <div className="space-y-6">
            {/* Stock Widget */}
            <Card className="shadow-lg">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold tesla-dark mb-4">TSLA Live Data</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Current Price</span>
                    <span className="text-2xl font-bold tesla-dark">
                      ${stockData?.currentPrice || '248.50'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Change</span>
                    <span className="text-green-500 font-semibold">
                      +${stockData?.change || '12.40'} ({stockData?.changePercent || '5.2'}%)
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Volume</span>
                    <span className="tesla-dark font-medium">
                      {stockData?.volume || '24.7M'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Market Cap</span>
                    <span className="tesla-dark font-medium">
                      {stockData?.marketCap || '$784B'}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Analyst Insights */}
            <Card className="shadow-lg">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold tesla-dark mb-4">Analyst Insights</h3>
                <div className="space-y-4">
                  {sentiment?.analysts?.map((analyst, index) => (
                    <div key={index} className={`border-l-4 pl-4 border-${analyst.color}-500`}>
                      <div className={`text-${analyst.color}-600 font-semibold text-sm`}>
                        {analyst.rating}
                      </div>
                      <div className="text-gray-700 text-sm">
                        {analyst.firm} - {analyst.target}
                      </div>
                    </div>
                  )) || (
                    <>
                      <div className="border-l-4 border-green-500 pl-4">
                        <div className="text-green-600 font-semibold text-sm">BUY</div>
                        <div className="text-gray-700 text-sm">Morgan Stanley raises target to $300</div>
                      </div>
                      <div className="border-l-4 border-blue-500 pl-4">
                        <div className="text-blue-600 font-semibold text-sm">HOLD</div>
                        <div className="text-gray-700 text-sm">Goldman Sachs maintains $275 target</div>
                      </div>
                      <div className="border-l-4 border-yellow-500 pl-4">
                        <div className="text-yellow-600 font-semibold text-sm">NEUTRAL</div>
                        <div className="text-gray-700 text-sm">JP Morgan sets $250 price target</div>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Market Sentiment */}
            <Card className="shadow-lg">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold tesla-dark mb-4">Market Sentiment</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Bullish</span>
                    <div className="flex-1 mx-3 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-green-500 h-2 rounded-full" 
                        style={{ width: `${sentiment?.bullish || 72}%` }}
                      ></div>
                    </div>
                    <span className="text-green-600 font-medium">
                      {sentiment?.bullish || 72}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Bearish</span>
                    <div className="flex-1 mx-3 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-red-500 h-2 rounded-full" 
                        style={{ width: `${sentiment?.bearish || 28}%` }}
                      ></div>
                    </div>
                    <span className="text-red-600 font-medium">
                      {sentiment?.bearish || 28}%
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
