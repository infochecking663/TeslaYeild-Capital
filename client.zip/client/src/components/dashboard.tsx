import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import { TrendingUp, BarChart3, Zap, Shield } from "lucide-react";
import LoadingSpinner from "@/components/ui/loading-spinner";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/portfolio/stats'],
  });

  const { data: performance, isLoading: performanceLoading } = useQuery({
    queryKey: ['/api/portfolio/performance'],
  });

  const { data: stockChart, isLoading: stockLoading } = useQuery({
    queryKey: ['/api/stock/chart'],
  });

  const { data: holdings, isLoading: holdingsLoading } = useQuery({
    queryKey: ['/api/portfolio/holdings'],
  });

  const { data: stockData } = useQuery({
    queryKey: ['/api/stock'],
  });

  const portfolioChartData = performance ? 
    performance.labels.map((label: string, index: number) => ({
      name: label,
      value: performance.data[index]
    })) : [];

  const stockChartData = stockChart ? 
    stockChart.labels.map((label: string, index: number) => ({
      name: label,
      value: stockChart.data[index]
    })) : [];

  if (statsLoading || performanceLoading) {
    return (
      <section id="dashboard" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center">
            <LoadingSpinner />
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="dashboard" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold tesla-dark mb-4">Real-Time Investment Dashboard</h2>
          <p className="text-xl text-gray-600">
            Track your Tesla investment performance with institutional-grade analytics
          </p>
        </div>

        {/* Key Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-green-100 text-sm font-medium">Portfolio Value</div>
                  <div className="text-3xl font-bold">${stats?.totalValue || '12,847'}</div>
                  <div className="text-green-200 text-sm">
                    {stats?.dailyPnL || '+$284'} ({stats?.dailyPnLPercent || '+2.27'}%)
                  </div>
                </div>
                <TrendingUp className="h-8 w-8 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-blue-100 text-sm font-medium">Today's P&L</div>
                  <div className="text-3xl font-bold">{stats?.dailyPnL || '+$284'}</div>
                  <div className="text-blue-200 text-sm">{stats?.dailyPnLPercent || '+2.27'}%</div>
                </div>
                <BarChart3 className="h-8 w-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-red-100 text-sm font-medium">Tesla Stock Price</div>
                  <div className="text-3xl font-bold">${stockData?.currentPrice || '248.50'}</div>
                  <div className="text-red-200 text-sm">
                    +${stockData?.change || '12.40'} ({stockData?.changePercent || '5.2'}%)
                  </div>
                </div>
                <Zap className="h-8 w-8 text-red-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-purple-100 text-sm font-medium">Risk Score</div>
                  <div className="text-3xl font-bold">{stats?.riskScore || '7.2'}</div>
                  <div className="text-purple-200 text-sm">Moderate Risk</div>
                </div>
                <Shield className="h-8 w-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Portfolio Performance Chart */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold tesla-dark">Portfolio Performance</h3>
                <Select defaultValue="30days">
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30days">30 Days</SelectItem>
                    <SelectItem value="90days">90 Days</SelectItem>
                    <SelectItem value="1year">1 Year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="h-64">
                {performanceLoading ? (
                  <div className="flex items-center justify-center h-full">
                    <LoadingSpinner />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={portfolioChartData}>
                      <XAxis 
                        dataKey="name" 
                        axisLine={false}
                        tickLine={false}
                        tick={{ fontSize: 12, fill: '#6B7280' }}
                      />
                      <YAxis 
                        axisLine={false}
                        tickLine={false}
                        tick={{ fontSize: 12, fill: '#6B7280' }}
                        domain={['dataMin - 1000', 'dataMax + 1000']}
                      />
                      <Tooltip 
                        formatter={(value) => [`$${value?.toLocaleString()}`, 'Portfolio Value']}
                        labelStyle={{ color: '#374151' }}
                        contentStyle={{ 
                          backgroundColor: 'white', 
                          border: '1px solid #E5E7EB',
                          borderRadius: '8px'
                        }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke="var(--tesla-red)" 
                        strokeWidth={3}
                        dot={{ fill: 'var(--tesla-red)', strokeWidth: 2, r: 4 }}
                        activeDot={{ r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Tesla Stock Chart */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold tesla-dark">Tesla Stock (TSLA)</h3>
                <div className="flex items-center space-x-2">
                  <span className="text-green-500 text-sm font-medium">
                    +{stockData?.changePercent || '5.2'}%
                  </span>
                  <span className="text-2xl font-bold tesla-dark">
                    ${stockData?.currentPrice || '248.50'}
                  </span>
                </div>
              </div>
              <div className="h-64">
                {stockLoading ? (
                  <div className="flex items-center justify-center h-full">
                    <LoadingSpinner />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={stockChartData}>
                      <XAxis 
                        dataKey="name" 
                        axisLine={false}
                        tickLine={false}
                        tick={{ fontSize: 12, fill: '#6B7280' }}
                      />
                      <YAxis 
                        axisLine={false}
                        tickLine={false}
                        tick={{ fontSize: 12, fill: '#6B7280' }}
                        domain={['dataMin - 5', 'dataMax + 5']}
                      />
                      <Tooltip 
                        formatter={(value) => [`$${value}`, 'TSLA Price']}
                        labelStyle={{ color: '#374151' }}
                        contentStyle={{ 
                          backgroundColor: 'white', 
                          border: '1px solid #E5E7EB',
                          borderRadius: '8px'
                        }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#10B981" 
                        strokeWidth={3}
                        dot={{ fill: '#10B981', strokeWidth: 2, r: 4 }}
                        activeDot={{ r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Holdings Breakdown */}
        <Card>
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold tesla-dark mb-6">Investment Breakdown</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-tesla-red rounded-full mr-3"></div>
                    <span className="font-medium">TSLA Stock</span>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{holdings?.tsla?.value || '$8,500'}</div>
                    <div className="text-sm text-gray-600">{holdings?.tsla?.percentage || '66.2%'}</div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                    <span className="font-medium">Tesla ETF</span>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{holdings?.etf?.value || '$3,200'}</div>
                    <div className="text-sm text-gray-600">{holdings?.etf?.percentage || '24.9%'}</div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                    <span className="font-medium">Cash Reserve</span>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{holdings?.cash?.value || '$1,147'}</div>
                    <div className="text-sm text-gray-600">{holdings?.cash?.percentage || '8.9%'}</div>
                  </div>
                </div>
              </div>
              <div className="md:col-span-2">
                <img 
                  src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" 
                  alt="Financial dashboard with charts and graphs" 
                  className="rounded-lg w-full h-48 object-cover" 
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
