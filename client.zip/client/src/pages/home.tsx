import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import InvestmentPlans from "@/components/investment-plans";
import Dashboard from "@/components/dashboard";
import TeslaNews from "@/components/tesla-news";
import FinancialTools from "@/components/financial-tools";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main>
        <HeroSection />
        <InvestmentPlans />
        <Dashboard />
        <TeslaNews />
        <FinancialTools />
      </main>
      <Footer />
    </div>
  );
}
